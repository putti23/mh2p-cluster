Cluster 2.0 — instalator r2

Naprawa instalatora: brak zaleznosci od systemowego cmp.
Funkcjonalne pliki 2.0 i MANIFEST_V2 pozostaja niezmienione.
Po instalacji wymagany restart. Sukces tylko gdy log ClusterIntegration.log
zawiera CLUSTER_2_0_R2_RESULT=PASS_COMMITTED. Sam Done installing nie wystarcza.
Wersja diagnostyczna NIE jest czescia tej karty.
